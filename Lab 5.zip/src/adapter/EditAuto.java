package adapter;

public interface EditAuto {
	
	//public void editOptionName(String ModelName, String OptionSetname, String newname, String oldname);

	public void editOptionPrice(String Modelname, String OptionName, String Option, float newprice, int threadno);
}
