package adapter;
import java.util.Properties;

public interface CreateAuto {
	
	public void buildAuto(String fileName);
	
	public void buildAutoProp(Properties props);
	
	public void printAuto(String modelName);

}
