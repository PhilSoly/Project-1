package adapter;

public interface GetChoice {
	
	public void getOptionChoice(String modelName, String setName);
	
	public void setOptionChoice(String modelName, String setName, String optionName);
}
