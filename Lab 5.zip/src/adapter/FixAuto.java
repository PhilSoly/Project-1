package adapter;

public interface FixAuto {
	
	public void fixAuto(int errornum);

}
