package adapter;
import server.AutoServer;
import client.AutoClient;

public final class BuildAuto extends proxyAutomobile implements CreateAuto, UpdateAuto, FixAuto, GetChoice, EditAuto, AutoServer, AutoClient{
	
}
