package server;

import java.util.Properties;
import adapter.BuildAuto;
import model.Automotive;

public class BuildCarModelOptions{

	private BuildAuto ba = new BuildAuto();
	//creates automotive and adds to linkedhashmap
	public void buildAutoProp(Properties props){
		ba.buildAutoProp(props);
	}
	
	public String getAutoModel(){
		return ba.getAutoModel();
	}
	
	public Automotive getAutomotive(String modelName){
		return ba.getAutomotive(modelName);
	}
}
