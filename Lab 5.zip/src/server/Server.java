package server;

import java.io.IOException;
import java.net.ServerSocket;

public class Server extends Thread{

	private ServerSocket serverSoc;
	//Start a server on a specific port
	public Server(int iPort) {
		try {
			serverSoc = new ServerSocket(iPort);
			System.out.println("Server Starting");
		} catch (IOException e) {
			System.out.println("Error --- " + e.toString());
			System.exit(1);
		}
	}

	public void run() {
		while(true) {
			try {
				/* I TRIED THIS BUT IT'S NOT NECESSARY
		    	System.out.println("Running thread");
		    	System.out.println("1");
		    	DefaultSocketServer dds = new DefaultSocketServer(serverSoc.accept());
		    	System.out.println("2");
		    	Thread t = new Thread(dds);
		    	System.out.println("3");
				t.start();
				*/
				System.out.println("Thread starting");
				new Thread(new DefaultSocketServer(serverSoc.accept())).start();
				System.out.println("Starting DSS");
			}catch (IOException e) {
				System.out.println("Error --- " + e.toString());
				System.exit(1);
			}
		}
	}
}
