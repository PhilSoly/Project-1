package server;

import java.util.Properties;
import model.Automotive;

public interface AutoServer {

	public void buildAutoProp(Properties props);
	
	public String getAutoModel();
	
	public Automotive getAutomotive(String modelName);

}
