package server;

import java.net.*;
import java.util.Properties;
import java.io.*;
//simple server class derived from DSS
public class DefaultSocketServer extends Thread implements SocketClientInterface, SocketClientConstants {
	
	private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket sock;
    private String strHost;
    private int iPort;
    private Object objCheck; //an object that gets information from the client
    private boolean looping;

    public DefaultSocketServer(Socket socHost) {       
    	System.out.println("Creating DSS");
    	sock = socHost;
		setPort (socHost.getPort());
		setHost(socHost.getInetAddress().getHostName());
    }

    public void run(){
    	System.out.println("Trying Connection");
    	if (openConnection()){
    		System.out.println("Open Connection");
    		handleSession();
    		closeSession();
       }
    }

    public boolean openConnection(){
    	try {
    		System.out.println("Obtaining client stream");
    		input = new ObjectInputStream(sock.getInputStream());
    	    output = new ObjectOutputStream(sock.getOutputStream());
    	    System.out.println("Got client stream");
    	   }catch (Exception e){
    		   if(DEBUG) 
    			   System.err.println("Unable to obtain stream to/from " + strHost);
    		   return false;
    	   }
    	return true;
    }

    public void handleSession(){
    	if (DEBUG) System.out.println ("Handling session with " + strHost + ":" + iPort);
    	looping = true;
    	sendClient("Let's go");
    	do{
    		handleInput();
    	}while(looping);
    	System.out.println("It's truely over -Server");
    }       

    public void sendClient(Object Output){
    	try {
    		output.writeObject(Output);
    	}catch (IOException e){
    		if (DEBUG) 
    			System.out.println("Error writing to " + strHost);
    	}
    }
    
    public void clientInput(){
		try{
			objCheck = input.readObject();
		}catch (ClassNotFoundException | IOException e){
			System.out.println("Error --- " + e.toString());
		}
	}
    //get the input from client and process a command from a switch statement
    public void handleInput(){
    	int operation = 0;
    	clientInput(); 
    	if(objCheck instanceof Integer)
    		operation = (int)objCheck;
    	BuildCarModelOptions bc = new BuildCarModelOptions();
    	switch(operation){
    	case 1:
    		System.out.println("Operation 1 from server"); 
    		clientInput();
    		if(objCheck instanceof Properties)
    			bc.buildAutoProp((Properties)objCheck);
    		System.out.println("Built an auto from the properties");
    		break;
    	case 2:
    		System.out.println("List of car models -Server");
    		sendClient(bc.getAutoModel());
    		System.out.println("Waiting for Automotive -Server");
    		clientInput();
    		if(objCheck instanceof String){
    			sendClient(bc.getAutomotive((String)objCheck));
    			System.out.println("Sent Automotive Properties -Server");
    		}else{
    			System.out.println("Spell the Automotive correctly! -Server");
    		}
    		break;
    	case -1:
    		System.out.println("I'm ending this -Server");
    		looping = false;
    		sendClient(null);
    		break;
    	default:
    		System.out.println("Enter a proper operation -Server");
    		break;
    	}
    		
    }
    
    public void closeSession(){
    	try {
    		output = null;
    		input = null;
    		sock.close();
    	} catch (IOException e){
    		if (DEBUG) System.err.println("Error closing socket to " + strHost);
    	}       
    }

    public void setHost(String strHost){
        this.strHost = strHost;
	}

	public void setPort(int iPort){
        this.iPort = iPort;
	}

}
