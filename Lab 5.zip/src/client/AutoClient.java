package client;
import java.io.IOException;
import java.util.Properties;

public interface AutoClient {

	public Properties uploadProp(String filename) throws IOException;
	
}
