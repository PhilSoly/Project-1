package scale;
import adapter.proxyAutomobile;

public class EditOptions extends proxyAutomobile{
	//variables for the new option price, as well as a boolean to check if the price is updated 
	private String ModelName, OptionName, Option;
	private float newprice;
	private boolean finished;
	private int threadno; //this is for us
	//private Thread t;
	//constructor
	//constructor has all the proper parameters for changing an optioon
	public EditOptions(String Modelname, String OptionName, String Option, float newprice, int threadno){
		this.ModelName = Modelname;
		this.OptionName = OptionName;
		this.Option = Option;
		this.newprice = newprice;
		this.threadno = threadno;
		finished = false; //you're not finished, so it's false
		//t = new Thread();
		//t.start();
	}
	//guide the user through the threading process by using system.out's
	public void run(){
		System.out.println("Starting the thread " + threadno);
		edit(); //call the synchronized method for changing the option price
		System.out.println("Thread " + threadno + " complete");
	}
	
	public synchronized void edit(){
		while(!finished){ //go through this process if the option price isn't updated
			//get whether or not the option price is successfully updated
			finished = updateOptionPrice(ModelName, OptionName, Option, newprice);
			if(!finished){ //go through a wait process if the option isn't updated
				try{
					System.out.println("OptionPriceUpdate waiting");
					wait();
				}catch(InterruptedException e){
					System.out.println("UpdatePrice finished + e: " + e.toString());
				}
			}
			System.out.println("Update Price is updated to " + newprice);
			notifyAll(); //notify any waiting threads to continue if they couldn't update an option
		}
	}
}
