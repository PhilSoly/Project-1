package util;
import model.Automotive;
import exception.AutoException;
import java.util.Properties;
import java.io.*;


public class FileIO{
	//method is used to return an Automotive object that is created from reading a text file
	@SuppressWarnings("resource") //suppress the file in case the baseprice isn't valid
	public Automotive buildAutoObject(String filename) throws AutoException{
		try {
			int counter = 0; //counter holds the index of OptionSet
			FileReader file = new FileReader(filename); //get the file location to be read
			BufferedReader buff = new BufferedReader(file); //use a BufferedReader to go through the content of the file
			//Create an Automotive that reads the first line for the name, second line for the base-price, and third line for the number of options
			String line = buff.readLine();
			String makeModel[] = line.split(" ", 2);
			double baseprice;
			//use a try-catch to check if the baseprice is a valid double, and doesn't have any strings
			try{
				baseprice = Double.valueOf(buff.readLine().trim());
			}catch (NumberFormatException e){
				throw new AutoException(e.toString(), 5);
			}
			Automotive temp = new Automotive(makeModel[0], makeModel[1], baseprice, Integer.valueOf(buff.readLine().trim()));
			boolean eof = false; //boolean to check if there is more content to a file
			while (!eof) { //keep the loop going if there is more text in the file
				line = buff.readLine(); //use a string to hold the next line, which should be an option name
				if (line == null) //check if the file has no more content
					eof = true; //prepare to exit the loop
				else{ //if there is more content, then add it to the automotive
					//set the OptionSet to the name from the String line, then the second line is the amount of options, and the counter specifies the index within OptionSet
					int loop = Integer.valueOf(buff.readLine().trim());
					temp.setOptionSet(line, loop, counter);
					for (int i=0; i<loop; i++){ //use an int i to go through all the options
						line = buff.readLine(); //get the name of the option
						temp.setOption(line, Float.valueOf(buff.readLine().trim()), i, counter); //set the option's name and value in the right index
					}
					counter++; //go to the next index in the OptionSet[] array
				}
			}
			buff.close(); //close the file since there's nothing left to read
			return temp; //return the newly created automotive with all the properties from the file
		} catch (IOException e){ //catch any errors that might occur when trying to read the file, and set them accordingly to the exception
			System.out.println("Error -- " + e.toString());
			throw new AutoException(e.toString(), 1);
		} catch (NumberFormatException e){
			throw new AutoException(e.toString(), 3);
		} catch (NullPointerException e){
			throw new AutoException(e.toString(), 4);
		}finally {
			
		}
	}
	
	public Automotive buildAutoProp(Properties props) throws AutoException {
		/*
		Properties props = new Properties();
		FileInputStream in;
		try {
			in = new FileInputStream(filename);
			props.load(in);
		} catch (FileNotFoundException e) {
			System.out.println("Error -- " + e.toString());
		} catch (IOException e) {
			System.out.println("Error -- " + e.toString());
		}
		*/
		Automotive temp = null;
		String carMake = props.getProperty("Make");
		System.out.println(carMake);
		if(!carMake.equals(null)){
			String carModel = props.getProperty("Model");
			double carBP= Double.valueOf(props.getProperty("BasePrice"));
			temp = new Automotive(carMake, carModel, carBP, 0);
			boolean more = true;
			int OptSetNum = 1;
			String OptSetPos;
			while(more){
				OptSetPos = "OptSet" + Integer.toString(OptSetNum);
				if(props.containsKey(OptSetPos)){
					temp.addOptionSet(props.getProperty(OptSetPos), 0);
					String OptNamePos = "OptName" + Integer.toString(OptSetNum) + "A";
					for(int i=0; props.containsKey(OptNamePos); i++){
						float OptPricePos = Float.valueOf(props.getProperty("OptPrice"+Integer.toString(OptSetNum) + Character.toString((char)(i+65))));
						temp.addOption(OptSetNum-1, props.getProperty(OptNamePos), OptPricePos);
						OptNamePos = "OptName" + Integer.toString(OptSetNum) + Character.toString((char)(i+66));
					}
					++OptSetNum;
				}else
					more = false;
			}
		}
		return temp;
		
	}
	//make a property object to send to server from client
	public Properties makeProp(String filename) throws IOException{
		Properties props = new Properties();
		FileInputStream in = new FileInputStream(filename);
		props.load(in);
		return props;
	}
	
	
	//Serialize a automotive to any file that could read from later, giving the user the option of where to output the file
	public void serializeAuto(Automotive temp, String location){
		try{
			//create an ObjectOutputStream to a the outSource.ser file within the util package
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(location));
			out.writeObject(temp); //write the automotive to the outSource.ser file
			out.close(); //close the file since it's done being used
		}
		catch(Exception e){ //catch any errors and exit the program if there's an error
			System.out.print("Error: " + e);
			System.exit(1);
		}
	}
	//Deserialize a file into an automotive object
	public Automotive deserializeAuto(String location){
		try{
			//create an ObjectInputStream from the file that needs to be deserialized
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(location));
			Automotive temp2 = (Automotive) in.readObject(); //read the file to create an automotive object
			in.close(); //close the file since it's done being used
			return temp2; //return the automotive that was created from the input file
		}
		catch(Exception e){ //catch any errors and exit the program if there's an error
			System.out.print("Error: " + e);
			System.exit(1);
		}
		return null; //return null 
	}
	
}
