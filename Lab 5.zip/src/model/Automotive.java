package model;
import java.io.Serializable;
import java.util.ArrayList;

import exception.AutoException;

public class Automotive implements Serializable { //just implement 
	//create an UID to make sure that the object being serialized is compatible with these classes
	private static final long serialVersionUID = 1L;
	//create private variables for the name, base price and OptionSet[] array properties for this class
	private String make;
	private String model;
	private double baseprice;
	ArrayList<OptionSet> opset;
	ArrayList <Option> choice;
	//default constructor will set name to "", bas	e-price to 0, and OptionSet[] to hold 0 options
	public Automotive(){
		make = "";
		model = "";
		baseprice = 0;
		opset = new ArrayList<OptionSet>(0);
		choice = new ArrayList<Option>(0);
	}
	//constructor that sets the name, base-price, and size of the OptionSet to the desired variables 
	public Automotive(String n, String m, double bp, int size){
		make = n;
		model = m;
		baseprice = bp;
		opset = new ArrayList<OptionSet>(size);
		choice = new ArrayList<Option>(size);
		for(int i=0; i<size; i++){ //instantiate objects to avoid NullPointerExcpetion
			opset.add(new OptionSet());
			choice.add(new Option());
		}
	}
	//return the automotive's name
	public String getMake(){
		return make;
	}
	public String getModel(){
		return model;
	}
	//return the automotive's base-price
	public double getBasePrice(){
		return baseprice;
	}
	public int getOptSetSize(){
		return opset.size();
	}
	public int getOptSize(int i){
		return opset.get(i).getLength();
	}
	public String getOptSetName(int i){
		return opset.get(i).getName();
	}
	public float getOptPrice(int i, int j){
		return opset.get(i).getOption(j).getPrice();
	}
	public String getOptName(int i, int j){
		return opset.get(i).getOption(j).getName();
	}
	//return the automotive's set of options
	public OptionSet getOptionSet(int index){
		return opset.get(index);
	}
	public String getOptionChoiceName(String setName){
		return getOptionSet(findOptionSet(setName)).getOptionChoice().getName();
	}
	public float getOptionChoicePrice(String setName){
		return getOptionSet(findOptionSet(setName)).getOptionChoice().getPrice();
	}
	public void setOptionChoice(String setName, String optionName){
		int opI = findOptionSet(setName);
		if(opI!=-1)
			choice.get(opI).setName(optionName);
	}
	public void setOptionChoice(int i, int j){
		opset.get(i).setOptionChoice(j);
	}
	public double getTotalPrice(){
		double total = baseprice;
		for(int i=0; i<choice.size(); i++)
			total+=choice.get(i).getPrice();
		return total;
	}
	//find the index of an OptionSet by searching for it's name
	public int findOptionSet(String n){
		for(int i=0; i<opset.size(); i++)
			if(opset.get(i).getName().equals(n))
				return i;
		return -1; //if it isn't found, return -1
	}
	//find an option within an OptionSet by searching for it's name, given it's OptionSet index 
	public int findOption(String n, int index){
		return opset.get(index).findOption(n); //return the index of the option by using the findOption method in the OptionSet class
	}
	//change the name of the automotive
	public void setMake(String n){
		make = n;
	}
	public void setModel(String n){
		model = n;
	}
	//change the base-price of the automotive
	public void setBasePrice(double bp){
		baseprice = bp;
	}	
	//Set the optionSet's name and length by using the set methods from the OptionSet class
	public void setOptionSet(String n, int i, int index) throws AutoException{
		try{
			opset.get(index).setName(n);
			opset.get(index).setOptionLength(i);
		}catch (ArrayIndexOutOfBoundsException e){
			System.out.println("got'em");
			throw new AutoException(e.toString(), 2);
		}
	}
	//change the values of an option, given the index of the OptionSet and the Option
	public void setOption(String n, float f, int indexOption, int indexOptionSet){
		opset.get(indexOptionSet).setOption(n, f, indexOption);
	}
	//Create an array with a new length by replacing old array with a new one
	public void setOptionSetLength(int j){
		for(int i=opset.size(); i<j; i++){ //instantiate objects to avoid NullPointerExcpetion
			opset.add(new OptionSet());
		}
	}
		//Add a new OptionSet with the amount of Options for it
	public void addOptionSet(String n, int length){
		opset.add(new OptionSet(n, length));
	}
	public void addOption(int pos, String n, float price){
		opset.get(pos).addOption(n, price);
	}
	//delete an OptionSet and replace the old array with a new one that doesn't have a null value
	public void deleteOptionSet(int i){
		opset.get(i).deleteOptionSet(); //set the OptionSet to null to know which element to remove
	}
	//delete an Option given the index of OptionSet[] and Option[]
	public void deleteOption(int i, int j){
		opset.get(i).deleteOption(j);
	}
	//update an OptionSet, given the name of the OptionSet and a new OptionSet
	public void updateOptionSetName(String n, String opt){
		if(findOptionSet(n)!=-1)
			opset.get(findOptionSet(n)).setName(opt);
	}
	//update an Option given the name of the OptionSet and the Option: maybe edit this
	public void updateOption(String osName, String oName, float f){
		if(findOptionSet(osName)!=-1 && findOption(oName, findOptionSet(osName))!=-1)
			setOption(oName, f, findOptionSet(osName), findOption(oName, findOptionSet(osName)));
	}
	public void updateOptionName(String osName, String oName, String nName){
		if(findOptionSet(osName)!=-1 && findOption(oName, findOptionSet(osName))!=-1)
			setOption(osName, 1, findOptionSet(osName), findOption(oName, findOptionSet(osName)));
	}
	//print function to output the properties of the automotive
	public String print(){
		StringBuffer temp = new StringBuffer("This model's make is "); //use a stringbuffer to hold the information
		temp.append(make);
		temp.append(" and its model is ");
		temp.append(model);
		temp.append(" and it's baseprice is $");
		temp.append(baseprice);
		temp.append(" and it has ");
		temp.append(opset.size());
		temp.append(" options\n");
		for(int i=0; i<opset.size(); i++) //add all the OptionSet properties to the information to print
			if(opset.get(i) != null)
				temp.append(opset.get(i).print());
		return temp.toString(); //return all the information about automotive
	}
	
	public String printOpts(){
		StringBuffer temp = new StringBuffer("This model's make is "); //use a stringbuffer to hold the information
		temp.append(make);
		temp.append(" and its model is ");
		temp.append(model);
		temp.append(" and it's baseprice is $");
		temp.append(baseprice);
		temp.append(" and it has ");
		temp.append(opset.size());
		temp.append(" options\n");
		for(int i=0; i<opset.size(); i++) //add all the OptionSet properties to the information to print
			if(opset.get(i) != null)
				temp.append(opset.get(i).printOpts());
		return temp.toString(); //return all the information about automotive
	}
}
