package model;

public class Truck extends Automotive{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
