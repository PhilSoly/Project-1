package model;

import java.util.LinkedHashMap;
import java.util.Set;

public class Containment <T extends Automotive>{
	//the hashmap follows a model name to automotive mapping
	LinkedHashMap<String, T> carModels = new LinkedHashMap<>(); 
	
	public Containment(){}
	//print out all the automotives
	public String getCarModels(){
		Set<String> key = carModels.keySet();
		StringBuffer temp = new StringBuffer("The list of cars avaible are:\n");
		Automotive car = null;
		for (String n : key){
			car = (Automotive) carModels.get(n);
			temp.append(car.getModel());
			temp.append("\n");
		}
		return temp.toString();
	}
	
	public void addAutomotive(String n, T t){
		carModels.put(n, t);
	}
	public Automotive getAutomotive(String n){
		return (Automotive)carModels.get(n);
	}
	public void updateOption(String model, String OptionSetName, String OptionName, float newPrice){
		carModels.get(model).updateOption(OptionSetName, OptionName, newPrice);
	}
	public void updateOptionSetName(String model, String OptionSetName, String newName){
		carModels.get(model).updateOptionSetName(OptionSetName, newName);
	}
	public void updateOptionPrice(String model, String opsetName, String opName, float price){
		carModels.get(model).updateOption(opsetName, opName, price);
	}
	
	//find an automotive by the index
	public int findAutomotiveIndex(T t){
		int index = -1;
		Set<String> key = carModels.keySet();
		for(String n: key)
			if(((T)carModels.get(n)).getModel().equals(t.getModel()))
				index = Integer.valueOf(n);
		return index;
	}
	
	public void deleteAutomotive(String n){
		carModels.remove(n);
	}
	
	public void printAutomotive(String n){
		System.out.println(carModels.get(n).print());
	}
	
}
