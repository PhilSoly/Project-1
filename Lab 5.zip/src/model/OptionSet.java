package model;
import java.io.Serializable;
import java.util.ArrayList;

public class OptionSet implements Serializable {
	//create an UID to make sure that the object being serialized is compatible with these classes
	private static final long serialVersionUID = 1L;
	//create private variables for the name and option[] array properties for this class
	private String name;
	private ArrayList<Option> opt;
	private int choiceIndex;
	//default constructor will fill name with "" and set the opt[] array to 0
	protected OptionSet(){
		name = "";
		opt = new ArrayList<Option>(0);
		choiceIndex = 0;
	}
	//constructor will set the name and opt[] array size to the desired variables
	protected OptionSet(String n, int size){
		opt = new ArrayList<Option>(size);
		name = n;
		choiceIndex = 0;
		for(int i=0; i<size; i++){ //instantiate objects to avoid NullPointerExcpetion
			opt.add(new Option());
		}
	}
	
	//Return the name of the OptionSet
	protected String getName(){
		return name;
	}
	
	//Get the length of the option array list
	protected int getLength(){
		return opt.size();
	}
	//Returns an the option at a specific index
	protected Option getOption(int i){
		return opt.get(i);
	}
	
	protected Option getOptionChoice(){
		return opt.get(choiceIndex);
	}
	//set an optionchoice with the option name
	protected void setOptionChoice(String opName){
		for(int i=0; i<opt.size(); i++)
			if(opt.get(i).getName().equals(getOptionChoice().getName()))
				choiceIndex=i;
	}
	protected void setOptionChoice(int i){
		choiceIndex=i;
	}
	//Find the index of an option by searching for the option's name
	protected int findOption(String n){
		for(int i=0; i<opt.size(); i++) //go through the entire option array
			if(opt.get(i).getName().equals(n)) //if the option's name is the option the user is searching for
				return i; //return the index of the option
		return -1; //if the option isn't found, return -1
	}
	//Change the name of the OptionSet
	protected void setName(String n){
		name = n;
	}
	//Change the values of an option, given the index of the option
	protected void setOption(String n, float f, int index){
		opt.get(index).setName(n); //call the set methods for name and price
		opt.get(index).setPrice(f);
	}
	//Create an array with a new length by replacing old array with a new one
	protected void setOptionLength(int j){
		for(int i=opt.size(); i<j; i++){ //instantiate objects to avoid NullPointerExcpetion
			opt.add(new Option());
		}
	}
	//Add an Option to the OptionSet if there is the need
	protected void addOption(String n, float price){
		opt.add(new Option(n, price));
	}
	//Delete the OptionSet by nullifying it's properties
	protected void deleteOptionSet(){
		name = null;
		opt = null;
	}
	//delete an option from opt[] by making it null
	protected void deleteOption(int i){
		opt.remove(i); //clear the option at the index of the array
	}
	//update the value of an option by searching for the options name
	protected void updateOption(String n, float f){
		if(findOption(n) != -1) //if the option name exists, set the option to the new value
			setOption(n, f, findOption(n)); //set the option at the correct index by searching for the option's name
	}
	//print function to output the properties of the OptionSet
	protected String print(){
		StringBuffer temp = new StringBuffer("This optionset's name is "); //use a stringbuffer to get all the properties
		temp.append(name);
		temp.append(":\n");
		for(int i=0; i<opt.size(); i++) //go through all the options in the option set
			temp.append(opt.get(i).print()); //print each object from the OptionSet
		return temp.toString(); //return the string about OptionSet
	}
	
	protected String printOpts(){
		StringBuffer temp = new StringBuffer("This optionset's name is "); //use a stringbuffer to get all the properties
		temp.append(name);
		temp.append(":\nAnd your choice is ");
		temp.append(opt.get(choiceIndex).printOpts());
		return temp.toString(); //return the string about OptionSet
	}
}
