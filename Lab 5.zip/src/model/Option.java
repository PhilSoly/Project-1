package model;

import java.io.Serializable;

public class Option implements Serializable{
	//create an UID to make sure that the object being serialized is compatible with these classes
	private static final long serialVersionUID = 1L;
	
	//create private static variables for the name and price properties for this class
	private String name;
	private float price;
	//Default constructor will fill the name and price of this object to "" and 0
	protected Option(){
		name = "";
		price = 0;
	}
	//Set the option's properties to the desired variables
	protected Option(String n, float f){
		name = n;
		price = f;
	}
	//Simple get name method for this option
	protected String getName(){
		return name;
	}
	//Simple get price method for this option
	protected float getPrice(){
		return price;
	}
	//Set this option's name to something else
	protected void setName(String n){
		name = n;
	}
	//Set this option's price to a new value
	protected void setPrice(float f){
		price = f;
	}
	//update this option's name and value
	protected void updateOption(String n, float f){
		setName(n);
		setPrice(f);
	}
	//print function to output the properties of this option
	protected String print(){
		StringBuffer temp = new StringBuffer("This option's name is "); //use a stringbuffer to hold the option's properties
		temp.append(name);
		temp.append(" and its value is $");
		temp.append(price);
		temp.append("\n");
		return temp.toString(); //return the properties of this option
	}
	
	protected String printOpts(){
		StringBuffer temp = new StringBuffer(name); //use a stringbuffer to hold the option's properties
		temp.append(" with a value of $");
		temp.append(price);
		temp.append("\n");
		return temp.toString(); //return the properties of this option
	}
}