package model;

public class Electric extends Automotive{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
