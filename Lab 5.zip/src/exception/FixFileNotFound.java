package exception;

import adapter.BuildAuto;
import adapter.CreateAuto;
import java.util.Scanner;

public class FixFileNotFound {
	
	public FixFileNotFound(){
		super();
	}
	//keep asking the user for a location, until one is valid
	//also allow the user to enter 'default' for the location of a file that exists and works
	public void fix(){
		@SuppressWarnings("resource") //suppress the resource since it's only used to find the file location
		Scanner in = new Scanner(System.in);
		String file = "";
		System.out.println("Enter a valid file location (you can enter default to build the default FordZTW): ");
		file = in.nextLine();
		if(file.equals("default")){
			file = "src/util/carOptions.txt";
		}
		System.out.println(file);
		CreateAuto a1 = new BuildAuto();
		a1.buildAuto(file);
	}

}
