package exception;

import java.io.IOException;
import java.util.logging.*;

public class AutoException extends Exception {

	private static final long serialVersionUID = 1L;
	private int errornum;
	private String errormsg;
	
	public AutoException(){
		super();
	}
	
	public AutoException(String msg, int num){
		super();
		errormsg = msg;
		errornum = num;
	}
	
	public String getErrorMsg(){
		return errormsg;
	}
	
	public int getErrorNum(){
		return errornum;
	}
	//cycle through the different exceptions and fix the right error
	public void fix(int errorno){ 
		FixFileNotFound f1 = new FixFileNotFound();
		switch(errorno){
		case 1: //if the file location is invalid
			f1.fix();
			break;
		case 2: //if the user made the optionsetarray too short
			errormsg = "This is the OptionSetArrayLength error";
			System.out.println(errormsg);
			break;
		case 3: //if the user put a string instead of a float for an option
			errormsg = "Fix an Option's value";
			System.out.println(errormsg);
			break;
		case 4: //if the user doesn't finish the last option, it results in a null pointer exception
			errormsg = "Fixing a nullpointer exception for an option!";
			System.out.println(errormsg);
			break;
		case 5:
			errormsg = "Baseprice is not a valid double";
			System.out.println(errormsg);
			break;
		default:
			break;
		}
	}
	//A nice logging function that I found through stackoverflow
	//It creates an exception log and prints exceptions with a time stamp each time the program is run
	public void log(){
	    Logger logger = Logger.getLogger("Exceptions");  
	    FileHandler fh;
	    try {  //Use the try-catch to configure logger handler/formatter  
	        fh = new FileHandler("src/util/ExceptionList.log");  
	        logger.addHandler(fh);
	        SimpleFormatter formatter = new SimpleFormatter();  
	        fh.setFormatter(formatter);
	        logger.info(errormsg + " " + errornum); //write to the file
	    } catch (SecurityException e) {  
	        e.printStackTrace();
	    } catch (IOException e) {  
	        e.printStackTrace();
	    }  

	}
	
	public String print() {
		return "FixProblems [errorno=" + errornum + ", errormsg=" + errormsg; 
	}
}
